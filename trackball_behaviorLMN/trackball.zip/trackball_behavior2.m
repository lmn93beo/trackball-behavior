% clear variables
psychsr_go_root();
close all; clearvars; clearvars -global data; clc
global data

data.mouse = input('Mouse #: ');

%% default params

data.params.reward = 4;
data.params.rewardProb = 1; % probability of reward

% number of trials, proportions
data.params.numTrials = 1000;
data.params.freeChoice = 1;     % percentage of free choices

data.params.perRight = 0;     % percentage of right trials (out of all non-freechoice)
data.params.perStimA = 1;     % percentage of stimulus A (out of all non-freechoice)

data.params.antibiasRepeat = 0; % probability that antibias will repeat after a wrong trial
data.params.antibiasSwitch = 0; % probability that antibias will switch after a correct trial
data.params.antibiasNumCorrect = 1; % number of correct responses before forced switch

data.params.actionValue = 1;    % reward amt is associated with left/right response (in blocks)
data.params.freeForcedBlocks = 0; % switch between forced and free choice in blocks
data.params.linkStimAction = 0; % constant stimulus value, but link stimulus to left/right response (in blocks)
data.params.blockSize = [30 30]; % min/max block size
data.params.blockSeq = randperm(2); % sequence of blocks
data.params.blockRewards = 1;   % block size measured in # of rewards, rather than # of trials
data.params.firstBlockEqual = 0; % make first block equal rewards, 2nd block antibias

% movement parameters
data.params.threshold = 30*[1 1]; % in degrees, can have diff thresholds for left/right

% trial timing
data.params.itiDelay = 1;       % duration of pre-trial no-movement interval
data.params.extenddelay = 1;    % extend ITI until mouse stops moving for 1 sec
data.params.itiBlack = 0;       % keep screen black during ITI

data.params.lickInitiate = 0;   % if >0, reward amount for animal to initiates trial with lick
data.params.lickDelay = 1;      % delay after initiation before go cue

data.params.go_cue = 1;         % play go sound?
data.params.noMvmtTime = 0;     % time after stimulus onset where movement is not counted (Before go sound)
data.params.earlyAbort = 1;     % abort if move during noMvmtTime

data.params.responseTime = 3;   % maximum reaction time

data.params.rewardDelay = 2.5;  % time after stimulus offset to drink reward
data.params.punishDelay = 3;    % extra ITI on incorrect/timeout trials
data.params.rewardDblBeep = 0;  % double beep?

% stimulus
data.params.stims = {'square', 'diamond'}; % stimuli A and B
data.params.reversalFreq = 0;   % frequency of contrast reversal
data.params.contrast = 1;       % maximum amplitude/contrast
data.params.whitediamond = 1;   % make diamond white
data.params.freeBlank = 0;      % free choice is blank

data.params.flashStim = 0;      % flash stimulus for this long (if 0, do not flash)

%% mouse specific parameters

switch data.mouse
    
    case 115
        
        data.params.reward = [0 5];
        data.params.rewardProb = [0 0.75];
        data.params.freeChoice = 1;     % percentage of free choices
        data.params.perRight = 0;       % percentage of right trials (out of all non-freechoice)   
        
        data.params.blockSize = [10 20]; % min/max block size
        data.params.flashStim = 1;   % flash stimulus for this long (if 0, do not flash)
        data.params.freeBlank = 0;      % free choice is blank
        
    case 001
        data.params.reward = [0 5];
        data.params.rewardProb = [0 0.75];
        data.params.freeChoice = 1;     % percentage of free choices
        data.params.perRight = 0;       % percentage of right trials (out of all non-freechoice)   
        
        data.params.blockSize = [10 20]; % min/max block size
        data.params.flashStim = 0;   % flash stimulus for this long (if 0, do not flash)
        data.params.freeBlank = 0;      % free choice is blank
        data.params.blockSeq = [1 2]; % sequence of blocks
    case 002
        data.params.reward = [0 6];
        data.params.rewardProb = [0 0.75];
        data.params.freeChoice = 1;     % percentage of free choices
        data.params.perRight = 0;       % percentage of right trials (out of all non-freechoice)   
        
        data.params.blockSize = [10 20]; % min/max block size
        data.params.flashStim = 1;   % flash stimulus for this long (if 0, do not flash)
        data.params.freeBlank = 0;      % free choice is blank
        data.params.blockSeq = [2 1]; % sequence of blocks
    case 003
        data.params.reward = [5];
        data.params.rewardProb = [1];
        data.params.freeChoice = 1;     % percentage of free choices
        data.params.perRight = 0;       % percentage of right trials (out of all non-freechoice)   
        
        data.params.threshold = 2*[1 1]; % in degrees, can have diff thresholds for left/right
        data.params.responseTime = 10;   % maximum reaction time
        data.params.punishDelay = 0;    % extra ITI on incorrect/timeout trials
        
        data.params.blockSize = [10 20]; % min/max block size
        data.params.flashStim = 1;   % flash stimulus for this long (if 0, do not flash)
        data.params.freeBlank = 1;      % free choice is blank
        
        data.params.lickInitiate = 1;   % animal initiates trial with lick
        data.params.lickDelay = 0.5;      % delay after initiation before go cue
        data.params.itiBlack = 1;
    case 0
        % action value
        data.params.reward = [1.5 4.5]; % first block left=reward(1)
        data.params.rewardProb = [1 1];
        data.params.freeChoice = 0.2;     % percentage of free choices
        data.params.perRight = 0.5;     % percentage of right trials (out of all non-freechoice)
        
        data.params.antibiasRepeat = 0.6; % probability that antibias will repeat after a wrong trial
        
        data.params.flashStim = 1;   % flash stimulus for this long (if 0, do not flash)
        
        data.params.actionValue = 1;    % reward amt is associated with left/right response (in blocks)
        data.params.blockSize = [40 50]; % min/max block size
end

%% Setup
for i = 1:length(data.params.reward)
    [data.response.reward_amt(i),data.response.reward_time(i),...
        data.response.reward_cal] = psychsr_set_reward(data.params.reward(i));
end
if data.params.lickInitiate>0
    [~,data.response.init_time] = psychsr_set_reward(data.params.lickInitiate);
end

trackball_card_setup;       % setup both daq and serial port
trackball_sound_setup;
trackball_screen_setup;
trackball_stimuli_setup;
screen = data.screen; struct_unzip(screen);

%% randomize trials
maxrepeat = floor(log(0.125)/log(abs(data.params.perRight-0.5)+0.5)); if maxrepeat<0; maxrepeat = Inf; end;
data.stimuli.loc = psychsr_rand(1-data.params.perRight,data.params.numTrials,0,maxrepeat);
if ~(data.params.actionValue && data.params.freeForcedBlocks)
    maxrepeat = floor(log(0.125)/log(abs(data.params.freeChoice-0.5)+0.5)); if maxrepeat<0; maxrepeat = Inf; end;
    data.stimuli.loc(psychsr_rand(1-data.params.freeChoice,data.params.numTrials,0,maxrepeat)>1) = 3;
end
maxrepeat = floor(log(0.125)/log(abs(data.params.perStimA-0.5)+0.5)); if maxrepeat<0; maxrepeat = Inf; end;
data.stimuli.id = psychsr_rand(data.params.perStimA,data.params.numTrials,0,maxrepeat);

data.stimuli.block = ones(size(data.stimuli.loc)); % 1:left=reward(1), 2:left=reward(2)
bs = data.params.blockSeq;
if data.params.blockRewards
    if data.params.firstBlockEqual
        data.stimuli.block = 3*ones(size(data.stimuli.loc));    
    else
        data.stimuli.block = bs(1)*ones(size(data.stimuli.loc));
    end
    
elseif length(data.params.reward)>1 && max(data.params.blockSize) < Inf
    i = 0; j = 1;
    while i < length(data.stimuli.block)
        if length(data.params.blockSize)>1
            n = randi(data.params.blockSize);
        else
            n = data.params.blockSize;
        end
        data.stimuli.block(i+1:i+n) = bs(mod(j-1,length(bs))+1)*ones(1,n);
        if data.params.actionValue && data.params.freeForcedBlocks && bs(mod(j-1,length(bs))+1) < 3
            data.stimuli.loc(i+1:i+n) = 3;            
        end
        i = i+n; j = j+1;
    end
    data.stimuli.block(length(data.stimuli.loc)+1:end) = [];
end

lastblock = 0;
nblocks = 0;
nrewards = 0;
if data.params.firstBlockEqual
    rewardSwitch = max(data.params.blockSize);
else
    rewardSwitch = min(data.params.blockSize);
end

% link stimulus id to action in blocks
if data.params.actionValue == 0 && data.params.linkStimAction
    ix = data.stimuli.loc<3;
    data.stimuli.id(ix) = xor(data.stimuli.loc(ix)-1,data.stimuli.block(ix)-1)+1;
    ix = data.stimuli.loc==3;
    data.stimuli.id(ix) = 3-data.stimuli.block(ix);
end    

data.stimuli.contrast = data.params.contrast(randi(length(data.params.contrast),1,data.params.numTrials));
data.stimuli.contrast(data.stimuli.loc==3) = max(data.params.contrast);

%% Loop through all the trials

% wait for movement
mvmt_test = true;
fprintf('testing trackball, waiting for mvmt...\n')
while mvmt_test
    bytes = data.serial.in.BytesAvailable;
    while bytes > 4
        [d,b] = fscanf(data.serial.in,'%d'); % read x and y
        bytes = bytes-b;
        if length(d) == 2 && d(2)~= 0
            mvmt_test = false;
            break;
        end
    end
    pause(0.1);
end
fprintf('movement detected.\n')
data.response.start_time = now;
start(data.card.ai);
nsampled = 0; % ai samples
data.response.lickdata = [];
data.response.serialdata = [];
data.quitFlag = 0;
data.userFlag = 0;
data.response.choice = [];
data.response.choice_id = [];
data.response.reward = [];

k = 0;
tstart = tic;
while k < data.params.numTrials && ~data.quitFlag
           
    % trial values
    k = k+1;            % trial number
    currX = 0;          % current trackball position (actual)
    currT = 0;          % current trial time    
    screenX = [];       % log of all screen positions
    ballX = [];         % log of all trackball positions
    samps = [];         % samples (serial) per loop
    timePC = [];        % log of all timestamps
    licks = [];         % log all licks
    choice = 0;         % current trial choice
    go = 0;             % count mvmts?
    % current screen position
    x = data.stimuli.startPos(data.stimuli.loc(k));  
    
    % ITI - force mouse to stop moving for 1s
    fprintf('%s ITI\n',datestr(toc(tstart)/86400,'MM:SS'))    
            
    % display behavioral performance
    if lastblock ~= data.stimuli.block(k)
        fprintf('\n\nSWITCH TO BLOCK %d: ',data.stimuli.block(k)); 
        if data.stimuli.block(k)==3 || length(data.params.reward) == 1
            fprintf('EQUAL\n')
        elseif data.params.actionValue
            fprintf('LEFT = %d\n',data.params.reward(data.stimuli.block(k)));
        elseif data.params.linkStimAction            
            fprintf('LEFT-%s = %d\n',upper(data.params.stims{data.stimuli.block(k)}),data.params.reward(data.stimuli.block(k)));
        else
            fprintf('%s = %d\n',upper(data.params.stims{1}),data.params.reward(data.stimuli.block(k)));
        end
            
        lastblock = data.stimuli.block(k);        
    end        
    str = trackball_dispperf;
    fprintf('%s',str);       
    
    if k>1 && mod(k,3) == 1
        fid = fopen(sprintf('rig%1d.txt',5),'w');
        str = [sprintf('RIG %1d\nMOUSE %2d\n%s TRIAL %d\n',5,...
            data.mouse,datestr(toc(tstart)/86400,'MM:SS'),k), str];
        fprintf(fid,'%s',str);
        fclose(fid);
    end
    
    
    % pre-trial delay period
    if data.params.lickInitiate>0
        % no licking for 1 second
        ttemp = tic;
        while toc(ttemp) < data.params.itiDelay
            trackball_keycheck(k);
            % record licks
            if data.card.ai.SamplesAcquired > nsampled
                newdata = peekdata(data.card.ai,data.card.ai.SamplesAcquired-nsampled);
                n = size(newdata,1);
                testdata = newdata; % testdata is newdata plus previous data point
                if ~isempty(data.response.lickdata)
                    testdata = [data.response.lickdata(end,:);testdata];
                end
                abovetrs = testdata > 1;
                crosstrs = find([0;abovetrs(2:end)-abovetrs(1:end-1)] > 0);
                if ~isempty(crosstrs) && data.params.extenddelay
                    if toc(ttemp) > 0.1;
                        fprintf('%s EXTEND DELAY...\n',datestr(toc(tstart)/86400,'MM:SS'));
                    end
                    ttemp = tic;
                end
                % store data
                nsampled = nsampled + n;
                data.response.lickdata = [data.response.lickdata; newdata];
            end
        end        
        % mouse must lick to initiate trial
        licked = 0;
        ttemp = tic; lastt = 1;
        while ~licked
            trackball_keycheck(k);
            if data.card.ai.SamplesAcquired > nsampled
                newdata = peekdata(data.card.ai,data.card.ai.SamplesAcquired-nsampled);
                testdata = [data.response.lickdata(end,:);newdata]; % testdata is newdata plus previous data point                
                abovetrs = testdata > 1;
                crosstrs = find([0;abovetrs(2:end)-abovetrs(1:end-1)] > 0);
                licked = ~isempty(crosstrs);
                % store data
                nsampled = nsampled + size(newdata,1);
                data.response.lickdata = [data.response.lickdata; newdata];
            end
            if toc(ttemp)>lastt
                fprintf('%s WAITING FOR LICK %ds...\n',datestr(toc(tstart)/86400,'MM:SS'),lastt);
                lastt = lastt+1;
                if lastt > 30;
                    licked = 1;
                    data.quitFlag = 1;
                end
            end
        end
        % deliver a small reward
        fprintf('%s INITIATE %duL\n',datestr(toc(tstart)/86400,'MM:SS'),data.params.lickInitiate)
        if data.response.init_time>0
            outdata = data.card.dio.UserData;
            outdata.dt(1) = data.response.init_time;
            outdata.tstart(1) = NaN;
            data.card.dio.UserData = outdata;
        end
        
        Screen('FillRect', window, grey)
        Screen('Flip', window);
        
        ttemp = tic;
        while toc(ttemp)<data.params.lickDelay
            pause(0.1) % pause allows reward to be administered
            trackball_keycheck(k);
        end
        
    else
        % mouse must stop moving for 1s to initiate trial
        ttemp = tic;
        bytes = data.serial.in.BytesAvailable;
        while toc(ttemp) < data.params.itiDelay
            trackball_keycheck(k);
            if bytes > 4
                [d,b] = fscanf(data.serial.in,'%d');
                bytes = bytes-b;
                if length(d) == 2
                    data.response.serialdata(end+1,:) = d;
                    if abs(d(2)) > 1 && data.params.extenddelay
                        if toc(ttemp) > 0.1;
                            fprintf('%s EXTEND DELAY...\n',datestr(toc(tstart)/86400,'MM:SS'));
                        end
                        ttemp = tic;
                    end
                end
            else
                bytes = data.serial.in.BytesAvailable;
            end
        end
    end
    
    % gray screen
    Screen('FillRect', window, grey)
    vbl = Screen('Flip', window);   
    
    % trial start
    fprintf('\n\n%s TRIAL %d START\n',datestr(toc(tstart)/86400,'MM:SS'),k)
    
    % collect extra serial samples
    bytes = data.serial.in.BytesAvailable;
    while bytes > 4
        trackball_keycheck(k);
        [d,b] = fscanf(data.serial.in,'%d');
        bytes = bytes-b;
        if length(d) == 2
            data.response.serialdata(end+1,:) = d;
        end
    end
    
    % log start time
    currT = tic;
    samples_start = size(data.response.serialdata,1);
    
    %% track ball movements    
    while choice == 0
         
        % collect serial samples
        n = 0;
        bytes = data.serial.in.BytesAvailable;
        while bytes > 4
            [d,b] = fscanf(data.serial.in,'%d'); 
            bytes = bytes-b;
            if length(d) == 2
                data.response.serialdata(end+1,:) = d; n = n+1;                
            end
        end
        
        % play go cue
        if go == 0 && toc(currT) > data.params.noMvmtTime
            go = 1;
            if data.params.go_cue% == 1
                psychsr_sound(17);
%             elseif data.params.go_cue==2
%                 psychsr_sound(18+data.stimuli.block(k));
            end
        end
            
        timePC(end+1) = toc(currT);
        
        % integrate values
        if go && n>0
            d_all = data.response.serialdata(end-n+1:end,2); 
        else
            d_all = 0;
            if ~go && n>0 && data.params.earlyAbort && max(abs(data.response.serialdata(end-n+1:end,2)))>1
                choice = 6;
                fprintf('%s EARLY ABORT - %1.2fs\n',datestr(toc(tstart)/86400,'MM:SS'),timePC(end))
            end
        end
        
        % multiply by gain to get screen position
        d = sum(d_all(d_all>0))*data.response.gain(1) + ...
            sum(d_all(d_all<0))*data.response.gain(2);        
        x = -d+x;
        
        % log actual ball movement/time
        currX = -sum(d_all,1) + currX;
        ballX(end+1) = currX;
        samps(end+1) = n;        
        
        
        % prevent cursor from moving beyond boundaries
        if sign(x) == sign(data.stimuli.loc(k)-1.5)
            x = 0;
        elseif abs(x) > data.stimuli.stopPos(1);
            x = sign(x)*data.stimuli.stopPos(1);
        end
        screenX(end+1) = x;
        
        % check for key press
        trackball_keycheck(k);
        
        %% Define choice threshold and save data when threshold is met.
        dstCenterRect = CenterRectOnPointd(data.stimuli.cursor, xCenter+x, yCenter);
        
        % check for choice
        if x == 0 % successfully moved to center            
            if data.stimuli.loc(k) == 3; choice = 2;
            else choice = data.stimuli.loc(k); end            
        elseif abs(x) == data.stimuli.stopPos(1) % moved to end
            if data.stimuli.loc(k) == 3; choice = 1;
            else choice = 3-data.stimuli.loc(k); end            
        elseif choice==0 && toc(currT) >= data.params.responseTime
            choice = 5; %5 -- a choice was not made within alloted time
            fprintf('%s TIMEOUT - %1.2fs\n',datestr(toc(tstart)/86400,'MM:SS'),timePC(end))
        end       
        
        % update performance markers
        if choice ~= 0 
            switch choice
                case 1; fprintf('%s LEFT - %1.2fs\n',datestr(toc(tstart)/86400,'MM:SS'),timePC(end))
                case 2; fprintf('%s RIGHT - %1.2fs\n',datestr(toc(tstart)/86400,'MM:SS'),timePC(end))
            end
        end           
        
        % Draw center cursor
        if choice==0
            color = [1 1 1]*grey*(1-data.stimuli.contrast(k)*cos(2*pi*data.params.reversalFreq*toc(currT)));
        else
            color = [1 1 1]*grey*(1-data.stimuli.contrast(k));
        end
        if choice < 6 && (data.params.flashStim==0 || toc(currT)<data.params.flashStim)            
            trackball_draw(k,x,color);
        end
        
        newvbl = Screen('Flip', window, vbl + (wait_frames-0.5)*flip_int);
        vbl = newvbl;
        
    end

    data.response.choice(k) = choice;
    data.response.choice_id(k) = id;
    
    %% reward or punish
    
    % save trial end time
    samples_stop = size(data.response.serialdata,1);

    if data.params.flashStim > 0
        Screen('FillRect', window, grey);
        Screen('Flip', window);
    end
    
    id = 5;
    if choice == 5 % timeout
        psychsr_sound(1);
        data.response.reward(k) = 0;
    elseif choice == 6 % abort sound
        psychsr_sound(18);
        data.response.reward(k) = 0;
    elseif choice == data.stimuli.loc(k) || data.stimuli.loc(k)==3 % correct choice
        if length(data.response.reward_time)==1
            id = 1;
        elseif data.params.actionValue % left/right
            if data.stimuli.block(k) == 3 % equal value
                [~,id] = max(data.params.reward);
            else
                id = xor(choice-1,data.stimuli.block(k)-1)+1;
            end
        elseif data.params.linkStimAction % diamond/square with fixed values
            if data.stimuli.loc(k) == 3
                id = ~xor(choice-1,data.stimuli.id(k)-1)+1;
            else
                id = data.stimuli.id(k);
            end
        else % diamond/square with values changing as function of block
            if data.stimuli.loc(k) == 3            
                id = xor(~xor(choice-1,data.stimuli.id(k)-1),data.stimuli.block(k)-1)+1;
            else
                id = xor(data.stimuli.id(k)-1,data.stimuli.block(k)-1)+1;
            end
        end
        if length(data.params.reward) > 1 && data.params.reward(id) == max(data.params.reward) && data.params.rewardDblBeep
            psychsr_sound(16);
        else
            psychsr_sound(6);
        end
        
        if rand < data.params.rewardProb(id)
            % deliver reward
            fprintf('%s REWARD %duL\n',datestr(toc(tstart)/86400,'MM:SS'),data.params.reward(id))
            if data.response.reward_time(id)>0
                outdata = data.card.dio.UserData;
                outdata.dt(1) = data.response.reward_time(id);
                outdata.tstart(1) = NaN;
                data.card.dio.UserData = outdata;
            end
            data.response.reward(k) = data.params.reward(id);
            
            % potentially change block
            nrewards = nrewards + 1;
            if nrewards == rewardSwitch && length(data.params.reward)>1
                nblocks = nblocks + 1;
                nrewards = 0;
                
                if data.params.firstBlockEqual
                    if nblocks == 1
                        if sum(data.response.choice(1:k)==1) > sum(data.response.choice(1:k)==2)
                            data.stimuli.block(k+1:end)=1; %left bias, reward right more
                        else
                            data.stimuli.block(k+1:end)=2;
                        end                        
                    else
                        data.stimuli.block(k+1:end) = 3-data.stimuli.block(k);
                    end
                else                
                    data.stimuli.block(k+1:end) = bs(mod(nblocks,length(bs))+1);
                end
                if length(data.params.blockSize)>1
                    rewardSwitch = randi(data.params.blockSize);
                end
            end
        else
            fprintf('%s REWARD 0uL\n',datestr(toc(tstart)/86400,'MM:SS'))
            data.response.reward(k) = 0;
        end
    else % incorrect choice
        psychsr_sound(3);
        data.response.reward(k) = 0;
    end
    
    for i = 1:10
        pause(0.1) % pause allows reward to be administered
        trackball_keycheck(k);
    end
    if data.params.itiBlack
        Screen('FillRect', window, black);
    else        
        Screen('FillRect', window, grey);
    end
    Screen('Flip', window);
    
    % antibias selects next trial
    if k+1 < data.params.numTrials && data.stimuli.loc(k) < 3 && data.userFlag ~= k+1
        
        lasttrial = find(data.stimuli.loc ~= data.stimuli.loc(k),1,'last');
        if isempty(lasttrial); lasttrial = 0; end;
        history = lasttrial+1:k;
                      
        nextstim = 0;
        nextid = 0;
        % if success on last trial
        if choice == data.stimuli.loc(k) && rand <= data.params.antibiasSwitch
            if sum(data.response.choice(history)==data.stimuli.loc(k)) >= data.params.antibiasNumCorrect            
                nextstim = 3-data.stimuli.loc(k); % switch side                
            else
                nextstim = data.stimuli.loc(k); % repeat side
            end
            
        % if failed on last trial        
        elseif choice ~= data.stimuli.loc(k) && rand <= data.params.antibiasRepeat
            nextstim = data.stimuli.loc(k); % repeat side
            data.stimuli.id(k+1) = data.stimuli.id(k); % repeat id and block also
            data.stimuli.block(k+1) = data.stimuli.block(k);
        end
        
        % change trial
        if nextstim > 0
            data.stimuli.loc(k+1) = nextstim;
            if nextstim == 1
                fprintf('ANTIBIAS: NEXT STIM LEFT\n')
            else
                fprintf('ANTIBIAS: NEXT STIM RIGHT\n')
            end
        end
        
    end
    
    % quit if 10 timeouts in a row
    if k >= 10 && min(data.response.choice(k-9:k))==5 
        data.quitFlag = 1;
    end
    
    % save post-trial ball movements
    ttemp = tic;
    bytes = data.serial.in.BytesAvailable;
    while toc(ttemp) < data.params.rewardDelay-1+data.params.punishDelay*(choice~=data.stimuli.loc(k) && ~(data.stimuli.loc(k)==3 && choice~=5))
        trackball_keycheck(k);
        if bytes > 4
            [d,b] = fscanf(data.serial.in,'%d'); % read x and y
            bytes = bytes-b;
            if length(d) == 2
                data.response.serialdata(end+1,:) = d;
            end
        else
            bytes = data.serial.in.BytesAvailable;
        end
    end
    
    % record licks    
    if data.card.ai.SamplesAcquired > nsampled
        newdata = peekdata(data.card.ai,data.card.ai.SamplesAcquired-nsampled);
        n = size(newdata,1);        
        testdata = newdata; % testdata is newdata plus previous data point
        if ~isempty(data.response.lickdata)
            testdata = [data.response.lickdata(end,:);testdata];
        end        
        abovetrs = testdata(end-data.params.rewardDelay*data.card.ai_fs:end) > 1;
        crosstrs = find([0;abovetrs(2:end)-abovetrs(1:end-1)] > 0);        
        licks(end+1) = length(crosstrs);        
        fprintf('%s LICKED %d TIMES\n',datestr(toc(tstart)/86400,'MM:SS'),licks(end))        
        % store data
        nsampled = nsampled + n;
        data.response.lickdata = [data.response.lickdata; newdata];        
    end
    
    % save trial variables
    data.response.trialtime(k) = toc(tstart);
    data.response.screenX{k} = screenX;
    data.response.ballX{k} = ballX;    
    data.response.samps{k} = samps;
    data.response.timePC{k} = timePC;
    data.response.samples_start{k} = samples_start;
    data.response.samples_stop{k} = samples_stop;
    data.response.samples_reward{k} = size(data.response.serialdata,1);
    data.response.licksamples{k} = size(data.response.lickdata,1);
end

%% Cleanup
psychsr_sound(3); 
fclose(data.serial.in);
delete(data.serial.in);
data.serial = rmfield(data.serial,'in');
putvalue(data.card.dio,0);
stop(data.card.dio)
delete(data.card.dio);
data.card = rmfield(data.card,'dio');
stop(data.card.ai);
delete(data.card.ai);
data.card = rmfield(data.card,'ai');
data = rmfield(data,'quitFlag');
data = rmfield(data,'userFlag');

% convert serial timestamps
time = data.response.serialdata(:,1);
neg = find(diff(time)<-1000,1);
while ~isempty(neg)
    time(neg+1:end,1) = time(neg+1:end,1) + 2^16;
    neg = find(diff(time)<-1000,1);
end
time = time/1000;
x = data.response.serialdata(:,2);
data.response.time = time;
data.response.dx = x;

% display performance
str = trackball_dispperf;
str = [sprintf('\nMouse %d\n',data.mouse), str];
fprintf('%s',str);

fid = fopen(sprintf('rig%1d.txt',5),'w');
fprintf(fid,'RIG %1d\nEMPTY\n',5);
fclose(fid);

%% save data
date = clock;
folder = sprintf('../behaviorData/trackball/mouse %04d',data.mouse);
if ~isdir(folder); mkdir(folder); end
uisave('data',sprintf('%s/%4d%02d%02d_trackball_%04d',folder,date(1),date(2),date(3),data.mouse));