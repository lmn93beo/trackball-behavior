function folder = psychsr_go_root()
    pc = getenv('computername');        
    if strcmp(pc,'ANALYSIS-2P4') || strcmp(pc,'BEHAVE-BALL1')
        folder = 'C:\Users\Surlab\Dropbox\MouseAttention\matlab';         
    else
        folder = 'C:\Dropbox\MouseAttention\matlab';    
    end
    
    cd(folder)
end