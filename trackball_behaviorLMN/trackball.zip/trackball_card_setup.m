function trackball_card_setup
global data

data.card.name = 'nidaq';
data.card.id = 'Dev1';
data.card.trigger_mode = 'none';
data.card.inter_trigger_interval = Inf;
daqreset;

data.card.dio_ports = [1,2];
data.card.dio_lines = [0 4];
data.card.dio = digitalio(data.card.name, data.card.id);

for i = 1:length(data.card.dio_ports)
    addline(data.card.dio, data.card.dio_lines(i), data.card.dio_ports(i), 'out');
end

% line 1 = reward
% line 2 = punish
% line 3/4 = other

data.card.dio.TimerFcn = @psychsr_dio_output;
data.card.dio.TimerPeriod = 0.01; % every 10ms

% initialize UserData structure
outdata.dt = zeros(size(data.card.dio_ports));
outdata.tstart = NaN*ones(size(data.card.dio_ports));
data.card.dio.UserData = outdata;

if ~strcmp(data.card.trigger_mode, 'out')
    start(data.card.dio);
end

data.card.ai = analoginput(data.card.name, data.card.id);
data.card.ai_chan = 2;
data.card.ai_fs = 64;
addchannel(data.card.ai, data.card.ai_chan);
set(data.card.ai, 'SampleRate', data.card.ai_fs);
set(data.card.ai,'TriggerType','Immediate');
set(data.card.ai, 'SamplesPerTrigger', inf);

%% arduino serial port
if ~isempty(instrfind)
    fclose(instrfind);
    delete(instrfind);
end
data.serial.port = 'COM5';
data.serial.in = serial(data.serial.port);
data.serial.in.InputBufferSize = 50000;
data.serial.in.BaudRate = 115200;
data.serial.in.FlowControl = 'hardware';
fopen(data.serial.in);

