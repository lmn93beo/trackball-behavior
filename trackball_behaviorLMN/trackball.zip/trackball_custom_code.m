function trackball_custom_code(k)
global data;
disp('CUSTOM CODE')
try
    % increase left threshold    
%     data.params.threshold(1) = data.params.threshold(1)+5;
%     fprintf('INCREASED LEFT THRESHOLD TO %d\n',data.params.threshold(1))
%     
    % decrease left threshold
%     data.params.threshold(1) = data.params.threshold(1)-5;
%     fprintf('DECREASED LEFT THRESHOLD TO %d\n',data.params.threshold(1))    
        
    % set both thresholds
 %   data.params.threshold = [20 20];
%     fprintf('SET BOTH THRESHOLDS TO %d\n',data.params.threshold(1))    
% data.params.threshold = 30*[1 1];
%     data.stimuli.block(k+1:end) = 3-data.stimuli.block(k);
%       fprintf('SET BLOCK TO %d\n',data.stimuli.block(k+1))    
    
%     data.params.punishDelay = 3;
% data.params.antibiasRepeat = 1; % probability that antibias will repeat after a wrong trial
% data.stimuli.id(k+1:k+5) = 2;
% data.stimuli.contrast(k+1:k+5) = 1;
% data.params.contrast = [0.25 0.5 1];
% data.stimuli.contrast(k+1:end) = data.params.contrast(randi(length(data.params.contrast),1,data.params.numTrials-k));

% data.stimuli.contrast(data.stimuli.loc==3) = max(data.params.contrast);
% 
% data.stimuli.block(k+1:k+20) = 2;
% ix = data.stimuli.loc<3;
% data.stimuli.id(ix) = xor(data.stimuli.loc(ix)-1,data.stimuli.block(ix)-1)+1;
% data.stimuli.id(k+1:k+100) = (rand(1,100)>=0.5)+1;
%     data.params.antibias = 1;       % probability that antibias will force next trial
%     data.params.freeChoice = 0.5;
%     data.param.numTrials = 200;
% data.params.responseTime = 3;
%      data.params.threshold = 10*[1 1];
% data.params.flashStim = 2;   

% data.params.reward = [0 3];
% for i = 1:length(data.params.reward)
%     [data.response.reward_amt(i),data.response.reward_time(i),...
%         data.response.reward_cal] = psychsr_set_reward(data.params.reward(i));
% end
% % data.params.punishDelay = 3;
% data.params.rewardDelay = 3.5;
% data.params.numTrials = 300;
% data.params.flashStim = 3;
% data.params.reversalFreq = 0;   % frequency of contrast reversal  
% data.params.threshold = 25*[1 1];
% data.params.stims = {'square'};
%  data.params.noMvmtTime = 0.3;  
%  data.params.contrast = 1;
% clear trackball_dispperf;
% data.params.freeBlank = 0;    
% data.params.reward = [0.5 3];
%data.params.antibiasRepeat = 0;
data.params.flashStim = 1;
% leave this uncommented
    data.response.gain = (data.stimuli.startPos(1)...
        *data.response.mvmt_degrees_per_pixel)./data.params.threshold;
  catch
    disp('ERROR IN CUSTOM CODE')
end
