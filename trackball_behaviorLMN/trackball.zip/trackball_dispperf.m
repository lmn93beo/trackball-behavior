function str = trackball_dispperf
global data

if data.params.actionValue
    choice = data.response.choice; 
    if ~isempty(choice)
        stim = data.stimuli.loc(1:length(choice));
        block = data.stimuli.block(1:length(choice));
        if data.params.blockRewards && length(data.params.reward)>1
            nb = 3;
        else
            nb = length(unique(data.stimuli.block));
        end
        if isfield(data.response,'timePC')
            rt = cellfun(@(x) x(end),data.response.timePC);
        else
            rt = [];
        end
        
        results = cell(1,3);
        label={'LEFT%% ','RIGHT%%','FREE%% '};
        rt_all = zeros(2,nb);
                
        for s = 1:3
            for b = 1:nb
                for c = [1 2 5]
                    results{s} = cat(1,results{s}, round(mean(choice(stim==s & block==b)==c)*100));                    
                end
                results{s} = cat(1,results{s}, sum(stim==s & block==b));
                if s < 3
                    rt_all(s,b) = mean(rt(choice==s & stim==s & block==b));
                end
            end
        end
                
        reward = data.params.reward;
        if length(reward)==1; reward(2) = NaN; end;
        
        str = '';        
        if nb > 1
            str = [str, sprintf('               LEFT=%d                    LEFT=%d   ',reward)];
        end
        if nb ~= 2
            str = [str, '               EQUAL'];
        end
        str = [str,sprintf('\n')];
        for s = 1:3
            str = [str, label{s}, sprintf('  %3d%%/%3d%%/%3d%% of %3d  ',results{s}), sprintf('\n')];
        end
        str = [str, sprintf('RT(L/R)    ')];
        for b = 1:nb
            str = [str,sprintf('  %01.3f/%01.3f             ',rt_all(:,b))];
        end
        str = [str, sprintf('\n')];
            
    else
        str = '';
    end
else
    
    choice = data.response.choice; stim = data.stimuli.loc(1:length(choice)); block=data.stimuli.id(1:length(choice));
    left = [mean(choice(stim==1 & block==1)==1), mean(choice(stim==1 & block==1)==2), mean(choice(stim==1 & block==1)==5); ...
        mean(choice(stim==1 & block==2)==1), mean(choice(stim==1 & block==2)==2), mean(choice(stim==1 & block==2)==5)];
    left = cat(2, round(left*100), [sum(stim==1 & block==1); sum(stim==1 & block==2)])';
    right = [mean(choice(stim==2 & block==1)==1), mean(choice(stim==2 & block==1)==2), mean(choice(stim==2 & block==1)==5); ...
        mean(choice(stim==2 & block==2)==1), mean(choice(stim==2 & block==2)==2), mean(choice(stim==2 & block==2)==5)];
    right = cat(2, round(right*100), [sum(stim==2 & block==1); sum(stim==2 & block==2)])';
    block=data.response.choice_id;
    free = [mean(choice(stim==3)==1), mean(choice(stim==3)==2), mean(choice(stim==3)==5); ... % left/right bias
        mean(block(stim==3)==1), mean(block(stim==3)==2), mean(block(stim==3)==5)];   % square/diamond bias
    free = cat(2, round(free*100), [sum(stim==3); sum(stim==3)])';
    str = '';
    str = [str, sprintf('           SQUARE                    DIAMOND\n')];
    str = [str, sprintf('LEFT%%  %3d%%/%3d%%/%3d%% of %3d    %3d%%/%3d%%/%3d%% of %3d\n',left)];
    str = [str, sprintf('RIGHT%% %3d%%/%3d%%/%3d%% of %3d    %3d%%/%3d%%/%3d%% of %3d\n',right)];
    str = [str, sprintf('         LEFT-RIGHT               SQUARE-DIAMOND\n')];
    str = [str, sprintf('FREE%%  %3d%%/%3d%%/%3d%% of %3d    %3d%%/%3d%%/%3d%% of %3d\n',free)];
    
end