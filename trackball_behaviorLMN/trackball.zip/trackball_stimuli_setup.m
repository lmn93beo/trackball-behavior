function trackball_stimuli_setup
global data
screen = data.screen; struct_unzip(screen);

x = X_pixels*0.2; % set cursor size to be 1/5 of screen width
y = x/ff;

data.stimuli.cursor = [0 0 x y];
data.stimuli.startPos = (X_pixels-x)/4*[1 -1 -1];
data.stimuli.stopPos = (X_pixels-x)/2*[1 -1];

data.response.mvmt_degrees_per_pixel = 3/20;
data.response.gain = (data.stimuli.startPos(1)...
    *data.response.mvmt_degrees_per_pixel)./data.params.threshold;


dwidth = sqrt(2)*x/2;
data.stimuli.diamond = [-dwidth, yCenter; ...
    0, yCenter+dwidth/ff; ...
    dwidth, yCenter; ...    
    0, yCenter-dwidth/ff];


bg_color_offset = [0.5, 0.5, 0.5, 1];
contrast_multiplier = 0.5;
radius = []; % full screen grating
data.stimuli.grating_tex = CreateProceduralSineGrating(screen.window,X_pixels,Y_pixels,...
    bg_color_offset,radius,contrast_multiplier);