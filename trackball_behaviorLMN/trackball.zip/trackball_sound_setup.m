function trackball_sound_setup
global data
data.sound.noise_amp = 0.25;
data.sound.noise_time = 2;
data.sound.tone_amp = 0.25;
data.sound.tone_time = 0.5;
data.sound.pahandle = 0;
data.sound.tone = 0;
data.sound.buffers = 0;   
psychsr_sound_setup();